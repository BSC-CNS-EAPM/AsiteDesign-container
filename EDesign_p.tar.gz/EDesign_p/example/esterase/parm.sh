

python2.7 -m /media/masoud/WRKP/EDesign/thirdparty/molfile2params/molfile_to_params --keep-names --clobber -n ${1%.*} -c  $1
